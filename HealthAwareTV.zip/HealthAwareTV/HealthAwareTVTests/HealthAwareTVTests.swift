//
//  HealthAwareTVTests.swift
//  HealthAwareTVTests
//
//  Created by STUDENT on 2026-10-17.
//

import Testing
@testable import HealthAwareTV

struct HealthAwareTVTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
